import React from "react";
import { Image, View } from "react-native";
import ScreenWrapper from "../../components/ScreenWrapper";
import colors from "../../const/colors";


export default function SplashScreen () {
    
    return (
        <ScreenWrapper>
            <View style={{justifyContent: "center", flexGrow: 1, alignItems: "center", backgroundColor: colors.background, width: '100%'}}>
                <Image source={require("../../assets/logo.png")} style={{width: 200, height: 200, resizeMode: "contain"}} />
            </View>
        </ScreenWrapper>
    )
}
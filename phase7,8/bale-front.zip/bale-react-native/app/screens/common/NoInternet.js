import React,{useEffect} from "react";
import { Text, View, StyleSheet, Image } from "react-native";

import {getToken} from "../../lib/auth"

import ScreenWrapper from "../../components/ScreenWrapper"
import FooterButton from "../../components/FooterButton";
import colors from "../../const/colors";

export default function NoInternet ({route, navigation}) {
    
    function call_function(){
        if (route.params.func instanceof Function) route.params.func()
        navigation.goBack(null)
    }

    return (
        <ScreenWrapper>
            <View style={styles.content}>
                {/* <Image style={{width: 120, height: 120, resizeMode: "contain"}} source={require('../../assets/icon/no-internet.png')} /> */}
                <Text style={{color: colors.neutralText, marginTop: 20,}}>خطایی در اتصال رخ داده است.</Text>
            </View>
            <View style={styles.footerButton}>
                <FooterButton onPress={call_function} title="تلاش دوباره" backgroundColor="#fff" borderColor={colors.neutralText} color={colors.neutralText} />
            </View>
        </ScreenWrapper>
    )
}

const styles = StyleSheet.create({

    content: {
        width: "100%",
        flexGrow: 1,
        marginBottom: 35,
        justifyContent: "center",
        alignItems: "center"
    },
    footerButton: {
        height: 75,
        width: "100%",
        position: "absolute",
        bottom: 0
    },
})
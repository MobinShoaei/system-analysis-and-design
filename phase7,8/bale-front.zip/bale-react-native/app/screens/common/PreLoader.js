import React from "react";
import { ActivityIndicator, Text, View } from "react-native";
import ScreenWrapper from "../../components/ScreenWrapper";
import colors from "../../const/colors";

export default function PreLoader () {
    
    return (
        <ScreenWrapper>
            <View style={{justifyContent: "center", flexGrow: 1, alignItems: "center", backgroundColor: colors.background}}>
                <ActivityIndicator size="large" color={colors.primary} />
                <Text style={{color: colors.neutralText, fontSize: 12, marginTop: 20}}>در حال بارگذاری...</Text>
            </View>
        </ScreenWrapper>
    )
}
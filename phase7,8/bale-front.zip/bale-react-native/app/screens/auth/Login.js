import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from "react";
import { ActivityIndicator, Image, Keyboard, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity,Picker, View } from "react-native";
import ScreenWrapper from "../../components/ScreenWrapper";
import colors, { ListOfCountries } from "../../const/colors";
import urls from "../../const/urls";
import words from "../../const/words";
import { sendReq } from "../../lib/api";
import { onSignIn } from "../../lib/auth";
import { isNetworkAvailable } from "../../lib/functions";
import { CodeField, Cursor, useBlurOnFulfill, useClearByFocusCell } from '../../modules/react-native-confirmation-code-field/esm';



export default function Login({ navigation }) {

    const navigationHook = useNavigation();


    const [phoneNumber, setPhoneNumber] = useState();
    const [error, setError] = useState('');
    const [timer, setTimer] = useState(0)
    const [code, setCode] = useState();
    const [interv, setInterv] = useState(null);
    const [activeTimer, setActiveTimer] = useState(false)
    const [selectedValue, setSelectedValue] = useState();

    const [loader, setLoader] = useState(false)

    const [screenType, setScreenType] = useState('phone') // code


    useEffect(() => {

        if (activeTimer) {
            setInterv(setInterval(() => {
                setTimer(timer => timer - 1);
            }, 1000))
        }
        return () => clearInterval(interv);
    }, [activeTimer]);


    const sendCode = () => {
        if (/^09[0-9]{9}$/.test(phoneNumber)) {
            // send req
            if (isNetworkAvailable()) {
                if (!loader) {
                    clearInterval(interv)
                    setActiveTimer(false)
                    setLoader(true)
                    console.log(urls.otp +"/?mobileNumber="+ phoneNumber,{}, 'get')
                    sendReq(urls.otp +"/?mobileNumber="+ phoneNumber,{}, 'get')
                    .then((res) => {
                        if (res.data.success == true) {
                            changeBox('code')
                            setError('')
                        }
                        else {
                            setError(res.data.message)
                        }
                    }).catch(e => {
                        if (e.response) {
                            // changeBox('code')
                            setError(e.response.data.detail)
                        } else {
                            //  
                            setError('خطا در اتصال')
                        }
                        setLoader(false)
                    })
                    .finally(() => setLoader(false))
                }
            }
            else
                setError('لطفا اتصال اینترنت را چک کنید')

        }
        else
            setError('شماره تلفن نامعتبر')

    }
    const updatePhoneNumber = text => {
        setPhoneNumber(text)
        if (text.length == 11) Keyboard.dismiss()
        setError('')
    }
    const updateCode = text => {
        setCode(text)
        if (text.length == 6) Keyboard.dismiss()
        setError('')
    }

    const checkCode = () => {
        if (!loader) {
            setLoader(true)
            sendReq(urls.login, {
                mobileNumber: phoneNumber,
                verificationCode: code,
            }, 'post')
            
            .then(res => {
                console.log(typeof res.data.isAuthenticated)
                if(res.data.isAuthenticated === true){
                    onSignIn(res.data.access_Token, res.data.refresh_Token)
                    navigationHook.reset({
                        index: 0,
                        routes: [{ name: 'ChatList' }],
                    });

                    setError('')
                    changeBox('phone')
                    setCode('')
                    setPhoneNumber('')
                }
                else
                    setError("کد وارد شده اشتباه است!")

            }).catch(e => {
                console.log(e.response.errors)
                setError('خطا در اتصال')
            })
            .finally(() => setLoader(false))
        }
    }

    const changeBox = (type) => {
        setScreenType(type)
        setError('')
        setCode('')
    }

    const ref = useBlurOnFulfill({ code, cellCount: 6 });
    const [props, getCellOnLayoutHandler] = useClearByFocusCell({
        code,
        setCode,
    });

    return (
        <ScreenWrapper>
            <View style={styles.loginContainer}>

                

                <View style={styles.body}>
                    <ScrollView style={{ width: "85%" }}>
                        {isNetworkAvailable() ?
                            <View style={styles.loginInputs}>
                                <Text style={{fontFamily: 'danaSemiBold',marginTop: 20,textAlign: "center",fontWeight: "bold",fontSize: 30,color:"#000"}}>{screenType == 'phone' ? "شماره همراه" : "کد فعال سازی"}</Text>
                                <Text style={styles.loginMessage}>{screenType == 'phone' ? 'شماره تلفن همراه خود را وارد کنید' : 'کد ارسال شده به شماره ' + phoneNumber + ' را وارد کنید'}</Text>
                                {screenType == 'phone' && <Text style={styles.loginDescription}>کد فعال سازی به این شماره ارسال خواهد شد</Text>}


                                {screenType == 'phone' ?
                                    <View style={{flexDirection:"column",justifyContent:"space-between",display:"flex",height:450}}>
                                         <View>

                                            <Picker
                                                selectedValue={selectedValue}
                                                style={{ height: 50, width: 150 }}
                                                onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
                                            >
                                                {ListOfCountries.map((item, i) =>{
                                                    return (

                                                        <Picker.Item label={item.name} value={item.dial_code} />
                                                    )
                                                })}
                                                
                                            </Picker>
                                            <TextInput
                                                onChangeText={updatePhoneNumber}
                                                value={phoneNumber}
                                                style={styles.input}
                                                keyboardType="phone-pad"
                                                placeholder={selectedValue}
                                            />
                                            {error != '' && <Text style={{ color: colors.red }}>{error}</Text>}
                                         </View>
                                        <TouchableOpacity style={styles.button} onPress={sendCode}>
                                            {loader ? <ActivityIndicator size="small" color={colors.input} /> : <Text style={{ color: '#fff', fontSize: 18 }}>دریافت کد</Text>}
                                        </TouchableOpacity>
                                    </View> :
                                    //code
                                    <View style={{flexDirection:"column",justifyContent:"space-between",display:"flex",height:550}}>
                                        <View>

                                            <TextInput
                                                value={code}
                                                style={{ alignItems: "center", marginTop: 20 }} 
                                                onChangeText={updateCode}
                                                onSubmitEditing={Keyboard.dismiss}
                                                keyboardType="number-pad"
                                                placeholder={"کد فعال سازی"}
                                            />
                                            {error != '' && <Text style={{ color: colors.red }}>{error}</Text>}
                                        </View>
                                        <View>

                                        <TouchableOpacity style={styles.button} onPress={checkCode}>
                                            {loader ? <ActivityIndicator size="small" color={colors.input} /> : <Text style={{ color: '#fff', fontSize: 18 }}>بررسی کد</Text>}
                                        </TouchableOpacity>
                                        
                                        <TouchableOpacity style={{ alignItems: "center", marginTop: 20 }} onPress={() => changeBox('phone')}><Text style={styles.label}>تغییر شماره موبایل</Text></TouchableOpacity>
                                        <TouchableOpacity style={{ alignItems: "center", marginTop: 10 }} onPress={sendCode}><Text style={styles.label} >ارسال مجدد کد</Text></TouchableOpacity>

                                        </View>

                                    </View>
                                }
                            </View> :
                            <Text>لطفا اتصال اینترنت را چک کنید</Text>
                        }
                    </ScrollView>
                </View>


            </View>
        </ScreenWrapper>
    )
}

const styles = StyleSheet.create({
    loginContainer: {
        flex: 1,
        backgroundColor: colors.background
        // justifyContent: "center",
        // alignItems: "center",
    },

    header: {
        // flex: 3,
        height: 280,
        overflow: "hidden",
        borderBottomLeftRadius: 70,
        borderBottomRightRadius: 70,
        justifyContent: "center",
        alignItems: "center",
    },
    imgContainer: {
        position: "absolute",
        top: 0,
        right: 0,
        left: 0,
        bottom: 0,
    },
    headerContent: {
        width: 150,
        height: "100%",
    },
    logo: {
        flex: 5,
        justifyContent: "center",
        alignItems: "center",
    },
    welcome: {
        flex: 3,
        justifyContent: "center",
        alignItems: "center",
    },
    // wrapper:{
    //     justifyContent:'space-around'
    // },

    body: {
        flex: 4,
        justifyContent: "center",
        alignItems: "center",
    },
    loginMessage: {
        marginTop: 10,
        textAlign: "center",
        color: colors.headingText,
        // fontSize: 14
        // marginHorizontal: 5
    },
    loginDescription: {
        marginTop: 10,
        marginBottom: 40,
        textAlign: "center",
        color: colors.headingText,
        // fontSize: 14
        // marginHorizontal: 5
    },
    loginInputs: {
        width: "100%",
    },
    label: {
        color: colors.primary,
        fontFamily: 'danaSemiBold',
        marginBottom: 10
    },
    input: {
        height: 40,
        textAlign: "left",
        paddingRight: 15,
    },
    button: {
        marginTop: 60,
        backgroundColor: colors.primary,
        borderRadius: 40,
        justifyContent: "center",
        alignItems: "center",
        height: 50
    },
    resendCode: {
        position: "absolute",
        right: 0,
        color: colors.neutralText
    },


})


function showTimer(timer) {
    var min = ("0" + (Math.floor(timer / 60).toString())).slice(-2);
    var sec = ("0" + (timer % 60).toString()).slice(-2);
    return (min + ':' + sec)
}
import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from "react";
import { Image, ScrollView, Text, TouchableOpacity, View } from "react-native";
import Header from "../../components/Header";
import ScreenWrapper from "../../components/ScreenWrapper";


export default function ChatList({ navigation }) {

    const navigationHook = useNavigation();


    useEffect(() => {

    //     let hubConnection = new HubConnectionBuilder().withUrl('https://localhost:7293/hub', {
    //   accessTokenFactory: () => this.loginToken,
    //   // skipNegotiation: true,
    //   // transport: HttpTransportType.WebSockets
    // }).build();
    //     hubConnection.serverTimeoutInMilliseconds = 300000;
    //     hubConnection.keepAliveIntervalInMilliseconds = 300000;

    // console.log('start calling hubconnection.start')

    //     hubConnection.start()
    //   .then(() =>
    //     console.log('connection start'))
    //   .catch(err => {
    //     console.log(`Error while establishing the connection ${err}`)
    //   });
    // console.log('end calling hubconnection.start')
    //     hubConnection.on('getConnections', (groups, privates) => {
    //   this.groups = groups;
    //   this.privates = privates;
    //   console.log(this.groups);
    //   console.log(this.privates);
    // })

    },[])

    return(
        <ScreenWrapper style={{backgroundColor:"#fff"}}>
            <Header title={<Image style={{width:75,height:50,color:"white"}} source={require("../../assets/index.png")}/>} right={<TouchableOpacity><Text style={{color: 'white', fontSize: 55,marginTop:8}}>+</Text></TouchableOpacity>} bgColor="#324a7d" />
            <ScrollView>
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
                <Chat />
            </ScrollView>
        </ScreenWrapper>
    )
}

function Chat({}){

    const navigationHook = useNavigation();

    function gotoChat() {

        navigationHook.reset({
            index: 0,
            routes: [{ name: 'Single' }],
        });
    }

    return(
        <TouchableOpacity onPress={gotoChat}>

            <View style={{display: 'flex', height: 80, flexDirection: 'row', marginBottom: 10}}>
                <View style={{flex: 2, justifyContent: 'center',flexDirection: 'row',padding:5}}>
                    <Image style={{width:60,borderRadius:60/2, height:60}} source={{uri: 'https://reactnative.dev/img/tiny_logo.png',}} />
                </View>
                <View style={{flex: 6,borderBottomColor:"#e2e2e2", borderWidth:1 ,borderColor:"transparent",padding:10 ,flexDirection: 'column',justifyContent:"space-around"}}>
                    <View style={{display: 'flex', flexDirection: 'row', justifyContent:"space-between",alignItems: "center"}}>
                        <Text style={{fontWeight: 'bold',fontSize:18,color:"black"}}>مبین</Text>
                        <Text>۲۱ دقیقه</Text>
                    </View>
                    
                    <Text style={{color: 'hsl(0, 0%, 23.7%)'}}>سلام خوبی؟</Text>
                </View>
            </View>
        </TouchableOpacity>
    )
}
import React, { useEffect, useRef, useState } from "react";
import { Image, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import Header from "../../components/Header";
import ScreenWrapper from "../../components/ScreenWrapper";


export default function Single({ navigation }) {


    const [data, setData] = useState(
        [
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: false,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: true,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: false,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: true,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: false,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: true,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: false,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: true,
                
            },
            {
                text: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است ",
                guest: false,
                
            }
        ]
    )

    const sendMessage = (t) => {
        console.log(t)
        let temp ={
            text: t.nativeEvent.text,
            guest: false,
            
        }
        setData(data => [...data, temp])
        
    }
    return(
        <ScreenWrapper style={{backgroundColor:"#fff"}}>
            <Header title={<Image style={{width:75,height:50,color:"white"}} source={require("../../assets/index.png")}/>} right={<TouchableOpacity><Text style={{color: 'white', fontSize: 55,marginTop:8}}>+</Text></TouchableOpacity>} bgColor="#324a7d" />
            <View style={{flexDirection:"column",justifyContent: 'space-between' ,flex:1}}>
                <View style={{maxHeight:530}}>
                    <ScrollView>
                       {data.map((item)=>{
                           return(
                               <ChatBox text={item.text} guest={item.guest}/>
                           )
                       })}
                        
                    </ScrollView>
                </View>
                <View>
                    <TextInput
                        style={{backgroundColor:"#e2e2e2",padding:15,borderRadius:0}}
                        onSubmitEditing={sendMessage}
                        keyboardType="text"
                        placeholder={"کد فعال سازی"}
                        
                    />
                </View>
            </View>
        </ScreenWrapper>
    )
}

function ChatBox(props){



    return(
        <View style={props.guest ? {flexDirection: "row-reverse"}:{flexDirection:"row"}}>

            <View style={props.guest ? {marginBottom: 10,backgroundColor:"#f1f1f1",width:"75%",padding:15,borderRadius:10}:{marginBottom: 10,backgroundColor:"#f9f9f9",width:"75%",padding:15,borderRadius:10}}>
                <Text style={{color: 'hsl(0, 0%, 23.7%)'}}>{props.text}</Text>
            </View>
           
        </View>
    )
}

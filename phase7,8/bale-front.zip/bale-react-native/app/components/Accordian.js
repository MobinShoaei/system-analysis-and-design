import React, { useState, useEffect } from 'react';
import { Image, View, TouchableOpacity, Text, StyleSheet, LayoutAnimation, Platform, UIManager } from "react-native";
import colors from '../const/colors';

export default function Accordian(props) {

    const [data, setData] = useState()
    const [expanded, setExpanded] = useState(false)

    useEffect(() => {
        if (Platform.OS === 'android') {
            UIManager.setLayoutAnimationEnabledExperimental(true);
        }
        setData(props.data)
    }, [props.data])


    const toggleExpand = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpanded(e => !e)
    }

    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.row} onPress={() => toggleExpand()}>
                <Text style={[styles.title, styles.font]}>{props.title}</Text>
                <Image source={require("../assets/icon/arrow.png")} style={[styles.arrow, expanded && { transform: [{ rotate: "90deg" }] }]} />
            </TouchableOpacity>
            {
                
                expanded &&
                <View style={styles.child}>
                    {data}
                </View>
            }

        </View>
    )
    

}

const styles = StyleSheet.create({
    title: {
        fontSize: 14,
        fontFamily: 'danaSemiBold',
        color: colors.headingText,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        height: 56,
        paddingLeft: 25,
        paddingRight: 18,
        alignItems: 'center',
        backgroundColor: "#fff",
        width: "100%"
    },
    child: {
        backgroundColor: "#fff",
        // padding:16,
    },
    arrow: {
        width: 15,
        height: 15,
        resizeMode: "contain",
        transform: [{
            rotate: "270deg"
        }]
    },

    container: {
        borderRadius: 10,
        overflow: 'hidden',
        width: "100%"
    },

});
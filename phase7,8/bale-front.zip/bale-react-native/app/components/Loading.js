import React from "react"
import { ActivityIndicator, View } from "react-native"
import colors from "../const/colors"

export default function Loading({color, size, style}){

    return (
        <View style={style}>
            <ActivityIndicator color={color ? color : colors.primary} size={size ? size : "small"} />
        </View>
    )
}
import React from "react"
import { TouchableOpacity, Image, Text } from "react-native"

// export default function BtnLightBlue({onPress}) { 
//     return (
//         <TouchableOpacity onPress={onPress} style={styles.addExercise}>
//             <Image style={{width: 12, height: 12, resizeMode: 'contain'}} source={require("../../../assets/icon/add.png")} />
//             <Text style={styles.addExerciseText}> افزودن ورزش جدید</Text>
//         </TouchableOpacity>
//     )
// }
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import Modal from 'react-native-modal';
import colors from "../const/colors";


export default function BottomModal(props){

    return (
        <Modal
            style={{ 
                justifyContent: "flex-end",
                margin: 0,
            }}
            swipeDirection={['down']}
            onSwipeComplete={props.setModal}
            useNativeDriver={true}
            isVisible={props.isVisible}
            onBackdropPress={props.setModal}>
            <View style={styles.container}>
                <View style={{margin:10}}>
                    <TouchableOpacity style={styles.closeModal} onPress={props.setModal} />
                </View>
                {props.children}
            </View>
        </Modal>
    )
}

const styles = StyleSheet.create({

    container:{ 
        width: "100%", 
        // height: 400,
        paddingBottom: 20,
        alignSelf: 'flex-end',
        backgroundColor: "#fff",
        borderTopLeftRadius: 25,
        borderTopRightRadius: 25,
    },

    closeModal:{
        width: 150,
        height: 5,
        backgroundColor: colors.input,
        alignSelf: "center",
        borderRadius: 5
    },
})
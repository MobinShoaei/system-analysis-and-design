import React from 'react'
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native'
// import SvgUri from 'react-native-svg-uri';

import colors from "../const/colors"
import Loading from './Loading'

export default function FooterButton (props){

    return(
        <View style={[styles.footer, {borderTopColor: props.areaBorderColor ? props.areaBorderColor : "#ccc"}]}>
            <TouchableOpacity 
                onPress={props.onPress} 
                style={[styles.btn, {
                    borderColor: props.borderColor ? props.borderColor : colors.primary,
                    backgroundColor: props.backgroundColor ? props.backgroundColor : colors.primary,
                    }]}
                >
                    {
                        props.loading ? 
                            <Loading color="#fff" /> :
                            <>
                                {props.prefix}
                                <Text 
                                    style={[styles.btnText, {
                                        color: props.color ? props.color : "#fff"
                                    }]}>{props.title}</Text>
                            </>
                    }
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    footer:{
        height: 75,
        width: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        // borderTopColor: "#ccc",
        borderTopWidth: 2,
        backgroundColor: "#fff",
        // position: "absolute",
        bottom: 0,
    },
    btn:{
        width: "80%",
        alignItems: 'center',
        padding: 8,
        borderRadius: 30,
        borderWidth: 1,
        flexDirection: "row",
        justifyContent: "center",
    },
    btnText:{
        fontSize: 12,
        fontFamily: 'danaBold',
    },
    
})
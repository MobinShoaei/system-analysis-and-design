import React from "react";
import { StyleSheet, Text } from 'react-native';
import colors from "../const/colors";


export default function EmptyListMessage (props) {
    return (
        <Text style={styles.label}>موردی یافت نشد</Text>   
    )
}


const styles = StyleSheet.create({
    label:{
        color: colors.neutralText,
        marginBottom: 10,
        textAlign:'center',  
        marginTop:40, 
        fontSize: 14,
        fontFamily: 'danaSemiBold'
    },
});
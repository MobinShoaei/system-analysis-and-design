import React from "react";
import { Platform, SafeAreaView, StatusBar, StyleSheet } from 'react-native';
import colors from "../const/colors";


export default function ScreenWrapper (props) {

    return (
        <SafeAreaView style={[styles.container, {backgroundColor: props.bg}, props.style]}>
            <StatusBar translucent backgroundColor={ props.statusBgColor ? props.statusBgColor : colors.primary} barStyle={ props.statusColor ?  props.statusColor : "light-content"} />
            {props.children} 
        </SafeAreaView>
    )
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: Platform.OS == "android" ? 20 : 0,

    //   marginTop: Platform.OS == "android" ? 20 : 0,
      overflow: "hidden"
    },
});
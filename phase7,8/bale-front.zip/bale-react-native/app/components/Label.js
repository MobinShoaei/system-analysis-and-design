import React from "react";
import { StyleSheet, Text} from 'react-native';

import colors from "../const/colors"

export default function Label (props) {
    return (
        <Text style={styles.label}>{props.title}</Text>   
    )
}


const styles = StyleSheet.create({
    label:{
        color: colors.primary,
        marginBottom: 10,
        fontSize: 16,
        fontFamily: 'danaSemiBold'
    },
});
import React  from "react"
import { StyleSheet, Text, TouchableOpacity, View, ActivityIndicator } from "react-native";

import colors from "../const/colors";

import CenterModal from "./CenterModal"

export default function DeleteModal(props){

    const {isVisible, setModal, submitBtn, cancelBtn, title, subTitle, loading} = props

    return (
        <CenterModal setModal={setModal} isVisible={isVisible}>
            <Text style={{alignSelf: 'center', fontFamily: 'danaBold'}}>{title}</Text>
            <Text style={{alignSelf: 'center', color: colors.neutralText}}>{subTitle}</Text>
            <View style={{flexDirection: 'row', marginTop: 30}}>
                <TouchableOpacity onPress={loading ? null : submitBtn} style={styles.submitName}>
                    {
                        loading ?
                        <ActivityIndicator color="#fff" size="small" /> : 
                        <Text style={{color: '#fff'}}>بله، حذف شود</Text>
                    }
                </TouchableOpacity>
                <TouchableOpacity onPress={cancelBtn} style={styles.back}>
                    <Text style={{color: colors.error}}>بازگشت</Text>
                </TouchableOpacity>
            </View>
        </CenterModal>
    )
}

const styles = StyleSheet.create({
    submitName:{
        flex: 3,
        backgroundColor: colors.secondary,
        marginRight: 10,
        padding: 7,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    back:{
        flex: 1,
        borderWidth: 1,
        borderColor: colors.error,
        padding: 7,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
})
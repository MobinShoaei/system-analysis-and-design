import React from "react"
import { StyleSheet, Text, View } from "react-native"
import colors from "../const/colors"

export default function Badge (props) {

    let icon = require("../assets/icon/arrow.png")
    if(props.icon == 'datepicker')
        icon = require('../assets/icon/calendar-prescription.png')
    

    return (
        <View style={[styles.badgeContainer,props.style]}>
                {
                    props.count !=0 &&
                    <Text style={styles.badge}>{props.count}</Text>
                }
            </View>
    )
}

const styles = StyleSheet.create({

    badgeContainer:{
        justifyContent: "center",
        alignItems: "center",
        position: 'absolute',
        right: 10,
        height: '100%',
        alignSelf: "center"
    },
    badge:{
        color: '#fff',
        backgroundColor: colors.red,
        paddingHorizontal: 5,
        fontSize: 11,
        borderRadius: 20,
        minWidth: 16,
        width:19,
        textAlign: 'center',
        textAlignVertical: 'center'
    },
})
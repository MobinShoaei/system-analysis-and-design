import React from 'react'
import {View, Text, StyleSheet, Image} from 'react-native'
// import SvgUri from 'react-native-svg-uri';

import colors from "../const/colors"

import patientBanner from '../assets/banner/patients.svg'

export default function ListHeader (props){
    var banner = '';
    if(props.banner != ''){
        if(props.banner == 'patient'){
            banner = <Image style={styles.image} source={require('../assets/banner/patients.png')} width={120} height={"100%"} />
        }
        else if(props.banner == 'exercise'){
            banner = <Image style={styles.image} source={require('../assets/banner/exercises.png')} width={120} height={"100%"} />
        }
    }
    return(
        <View style={styles.header}>
            <Text style={styles.headerText}>{props.title}</Text>
            <View style={styles.banner}>
                {banner}
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    header:{
        backgroundColor: colors.primary,
        height: "100%",
        justifyContent: "flex-end",
        paddingBottom: "4%",
        paddingLeft: 10,
        flexDirection: "row",
        flex: 1,
        alignItems: "flex-end",
        alignContent: "flex-end",
        width: "100%"
        
    },
    headerText:{
        // flex: 1,
        width: "50%",
        color: '#fff',
        fontSize: 30,
        alignSelf: "flex-end",
        fontFamily: "danaBold"
    },
    banner:{
        // width: 100,
        // height: 100,
        // flex: 1,
        width: "50%",
        alignSelf: "flex-end",
        marginRight: 5,
        // marginLeft: 0,
        // transform: [{
            // scaleX: 1,
        // }],
    },
    image:{
        // position: "absolute",
        marginTop: 5,
        width: 130,
        height: 130,
        resizeMode: "contain",
        alignSelf: "flex-end",
        // left: 0,
        // top: 0,
        // transform: [{
        //     scale: 1.2,
        // }],
    },
})
import React from 'react'
import {TouchableOpacity, Text, StyleSheet} from 'react-native'

import colors from "../const/colors"

export default function FloatBtn (props){

    return (
        <TouchableOpacity onPress={props.onPress} style={styles.floatBtn}>
            {props.prefix}
            <Text style={styles.title}>{props.title}</Text>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    floatBtn: {
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: 100,
        position: 'absolute',
        bottom: 10,
        alignSelf: "center",
        height: 40,
        backgroundColor: colors.darkBlue,
        borderRadius: 100,
        padding: 15,

        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 7,
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15,
        flexDirection: "row",
        
    },
    title:{
        color: "#fff",
    },
})
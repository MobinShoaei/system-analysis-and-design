import React from 'react';
import { StyleSheet, View } from 'react-native';
import Modal from 'react-native-modal';


export default function CenterModal(props){
    return (
        <Modal
            style={{ 
                justifyContent: "center",
                margin: 0,
            }}
            swipeDirection={['down']}
            useNativeDriver={true}
            onSwipeComplete={props.setModal}
            isVisible={props.isVisible}
            onBackdropPress={props.setModal}>
            <View style={styles.container}>
                {props.children}
            </View>
            
        </Modal>
    )
}

const styles = StyleSheet.create({

    container:{ 
        width: "90%",
        padding: 15,
        alignSelf: 'center',
        backgroundColor: "#fff",
        borderRadius: 25,
    },
})
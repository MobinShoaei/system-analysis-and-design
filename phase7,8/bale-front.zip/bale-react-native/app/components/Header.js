import React from 'react'
import { ActivityIndicator, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
// import SvgUri from 'react-native-svg-uri';
import colors from "../const/colors"

export default function Header (props){
    // const processBack=()=>{
    //     if(props.processBack){
    //         props.processBack()
    //     }
    //     else{
    //         if(props.beforeNavigate)
    //             props.beforeNavigate()
    //         props.navigation.goBack(null)
    //     }
    // }
    return(
        <View style={[styles.header, {backgroundColor: props.bgColor ? props.bgColor : colors.primary}]}>
            <View style={styles.right}>{props.right}</View>
            <View style={styles.center}>
                {
                    props.loading ? 
                    <ActivityIndicator size="small" color={colors.veryLightBlue} /> :
                    <View style={styles.title}>{props.title}</View>
                }
            </View>
            <View style={styles.left}>
                <TouchableOpacity style={styles.back}>
                    <Image style={styles.backImage} source={require("../assets/icon/magnifying-glass(1).png")} width={40} height={40} />
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    header:{
        height: 75,
        width: "100%",
        flexDirection: "row",
    },
    right:{
        flex: 1,
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
    },
    center:{
        flex: 3,
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
    },
    title:{
        color: "#fff",
        fontSize: 18,
    },
    left:{
        flex: 1,
        height: "100%",
        justifyContent: "center",
        alignItems: "center",
    },
    back:{
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
    },
    backImage:{
        resizeMode: "contain",
        width: 20,
        height: 20,
    },
    
})
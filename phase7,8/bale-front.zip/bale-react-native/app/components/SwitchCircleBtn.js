import React from 'react'
import {View, StyleSheet} from 'react-native'

import colors from "../const/colors"

export default function SwitchCircleBtn(props){
    const {active} = props
    return(
        <View style={styles.circleArea}>
            <View style={styles.outerCircle}>
                {active && <View style={styles.innerCircle} />}
            </View>
        </View>
    )
}


const styles = StyleSheet.create({

    circleArea:{
        // backgroundColor: "red",
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        // paddingRight: 5,
    },
    outerCircle:{
        width: 20,
        height: 20,
        backgroundColor: colors.input,
        borderRadius: 13,
        justifyContent: "center",
        alignItems: "center",
    },
    innerCircle:{
        width: 14,
        height: 14,
        backgroundColor: colors.secondary,
        borderRadius: 8,
    },
})
import React from "react"
import {TouchableOpacity, Text, View, Image, StyleSheet} from "react-native"
import colors from "../const/colors"

export default function SelectInput (props) {

    let icon = require("../assets/icon/arrow.png")
    if(props.icon == 'datepicker')
        icon = require('../assets/icon/calendar-prescription.png')
    

    return (
        <TouchableOpacity style={styles.select} onPress={props.onPress}>
            <Text style={styles.text}>{props.text}</Text>
            <View style={styles.arrowArea}><Image style={{width: 15, height: 15, resizeMode: 'contain'}} source={icon} /></View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({

    select:{
        backgroundColor: "#fff",
        borderWidth: 1,
        borderRadius: 10,
        borderColor: colors.secondary,
        padding: 4,
        flexDirection: "row",
    },
    arrowArea:{
        borderLeftColor: colors.secondary,
        borderLeftWidth: 1,
        flex: 1,
        justifyContent: 'center',
        alignItems: "center",
    },
    text:{
        flex: 9,
        padding: 6,
        color: colors.primary,
        textAlign: "left",
    },
})
If you have question about the usage of the library, please ask question on StackOverflow with tag [react-native-popup-menu](http://stackoverflow.com/questions/tagged/react-native-popup-menu). We are subscribed to it but it also allows community to help you if we are busy.

If you have found a bug, please describe your problem and expected behaviour. Additionally let us know library version, platform on which the problem happens and if possible some code snipets reproducing problem.

# History

# 2.2.2

- fix: support old version react-native, support both `View.propTypes` and `ViewPropTypes`

# 2.2.1

- fix: add missing `prop-types` `create-react-class`

# 2.2.0

- feature: swipe menu manual open, add `openLeft/openRight` properties. (https://github.com/dancormier/react-native-swipeout/pull/161)

# 2.1.5

-  fix: Added missing react import (https://github.com/dancormier/react-native-swipeout/pull/196)

# 2.1.4

- improve: Update PropTypes and React.createClass (https://github.com/dancormier/react-native-swipeout/pull/193)

# 2.1.2 ~ 2.1.3

- fix: Avoid Wrapping button text. (https://github.com/dancormier/react-native-swipeout/commit/6e7ee3adb6f1fd95bbd057c5ed2850562ae16e1c)

# * ~ 2.1.1

- see [commits history](https://github.com/dancormier/react-native-swipeout/commits/master)

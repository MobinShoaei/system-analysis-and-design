/**
 * Persian Calendar Picker Component
 *
 * Copyright 2016 Reza (github.com/rghorbani)
 * Licensed under the terms of the MIT license. See LICENSE file in the project root for terms.
 *
 * @flow
 */

'use strict';

const DEFAULT_SELECTED_BACKGROUND_COLOR = '#5ce600';
const DEFAULT_SELECTED_TEXT_COLOR = '#000000';
const DEFAULT_TODAY_BACKGROUND_COLOR = '#CCCCCC';

import colors from "../../../const/colors"

function getBorderRadiusByShape(scaler, dayShape) {
  if (dayShape === 'square') {
    return 0;
  } else {
    return 30 * scaler;
  }
}

function makeStyles({
  isRTL,
  initialScale: scaler,
  backgroundColor,
  textColor,
  todayBackgroundColor,
  dayShape,
}) {
  const SELECTED_BG_COLOR = backgroundColor
    ? backgroundColor
    : DEFAULT_SELECTED_BACKGROUND_COLOR;
  const SELECTED_TEXT_COLOR = textColor
    ? textColor
    : DEFAULT_SELECTED_TEXT_COLOR;
  const TODAY_BG_COLOR = todayBackgroundColor
    ? todayBackgroundColor
    : DEFAULT_TODAY_BACKGROUND_COLOR;

  return {
    calendar: {
      height: 320 * scaler,
      marginTop: 10 * scaler,
    },

    dayButton: {
      width: 48 * scaler,
      height: 48 * scaler,
      borderRadius: getBorderRadiusByShape(scaler, dayShape),
      alignSelf: 'center',
      justifyContent: 'center',
    },

    dayLabel: {
      fontSize: 14 * scaler,
      color: colors.secondary,//'#000',
      alignSelf: 'center',
    },

    selectedDayLabel: {
      color: SELECTED_TEXT_COLOR,
    },

    dayLabelsWrapper: {
      flexDirection: isRTL ? 'row-reverse' : 'row',
      // borderBottomWidth: 1,
      borderTopWidth: 1,
      paddingTop: 10 * scaler,
      paddingBottom: 10 * scaler,
      alignSelf: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(0, 0, 0, 0.0)',
      borderColor: 'rgba(0, 0, 0, 0.2)',
    },

    daysWrapper: {
      alignSelf: 'center',
      justifyContent: 'center',
      
    },

    dayLabels: {
      width: 48 * scaler,
      fontSize: 16 * scaler,
      color: colors.secondary,
      textAlign: 'center',
      fontFamily: 'danaBold'
    },

    selectedDay: {
      width: 48 * scaler,
      height: 48 * scaler,
      borderRadius: getBorderRadiusByShape(scaler, dayShape),
      alignSelf: 'center',
      justifyContent: 'center',
    },

    selectedDayBackground: {
      backgroundColor: SELECTED_BG_COLOR,
    },

    selectedToday: {
      width: 48 * scaler,
      height: 48 * scaler,
      backgroundColor: TODAY_BG_COLOR,
      borderRadius: getBorderRadiusByShape(scaler, dayShape),
      alignSelf: 'center',
      justifyContent: 'center',
    },

    dayWrapper: {
      alignItems: 'center',
      justifyContent: 'center',
      width: 48 * scaler,
      height: 48 * scaler,
      backgroundColor: 'rgba(0, 0, 0, 0.0)',
    },

    startDayWrapper: {
      width: 48 * scaler,
      height: 48 * scaler,
      borderTopLeftRadius: isRTL ? 0 : 20 * scaler,
      borderBottomLeftRadius: isRTL ? 0 : 20 * scaler,
      borderTopRightRadius: isRTL ? 20 * scaler : 0,
      borderBottomRightRadius: isRTL ? 20 * scaler : 0,
      backgroundColor: SELECTED_BG_COLOR,
      alignSelf: 'center',
      justifyContent: 'center',
    },

    endDayWrapper: {
      width: 48 * scaler,
      height: 48 * scaler,
      borderTopRightRadius: isRTL ? 0 : 20 * scaler,
      borderBottomRightRadius: isRTL ? 0 : 20 * scaler,
      borderTopLeftRadius: isRTL ? 20 * scaler : 0,
      borderBottomLeftRadius: isRTL ? 20 * scaler : 0,
      backgroundColor: SELECTED_BG_COLOR,
      alignSelf: 'center',
      justifyContent: 'center',
    },

    inRangeDay: {
      width: 48 * scaler,
      height: 48 * scaler,
      backgroundColor: SELECTED_BG_COLOR,
      alignSelf: 'center',
      justifyContent: 'center',
    },

    monthLabel: {
      fontSize: 16 * scaler,
      color: '#000',
      marginBottom: 10 * scaler,
      width: 180 * scaler,
      textAlign: 'center',
    },

    headerWrapper: {
      alignItems: 'center',
      flexDirection: isRTL ? 'row-reverse' : 'row',
      alignSelf: 'center',
      padding: 5 * scaler,
      paddingBottom: 3 * scaler,
      backgroundColor: 'rgba(0, 0, 0, 0.0)',
    },

    monthSelector: {
      marginBottom: 10 * scaler,
      fontSize: 14 * scaler,
      width: 80 * scaler,
    },

    prev: {
      textAlign: isRTL ? 'right' : 'left',
      
    },

    next: {
      textAlign: isRTL ? 'left' : 'right',
    },

    yearLabel: {
      fontSize: 14 * scaler,
      fontWeight: 'bold',
      color: '#000',
      textAlign: 'center',
    },

    weeks: {
      flexDirection: 'column',
    },

    weekRow: {
      flexDirection: isRTL ? 'row-reverse' : 'row',
    },

    disabledText: {
      fontSize: 14 * scaler,
      color: '#BBBBBB',
      alignSelf: 'center',
      justifyContent: 'center',
    },
  };
}

module.exports = makeStyles;

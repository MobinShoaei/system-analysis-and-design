/// <reference types="react" />
declare const _default: (_props: any) => JSX.Element;
export default _default;

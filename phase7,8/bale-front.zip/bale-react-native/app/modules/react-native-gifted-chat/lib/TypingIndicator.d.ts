/// <reference types="react" />
interface Props {
    isTyping?: boolean;
}
declare const TypingIndicator: ({ isTyping }: Props) => JSX.Element;
export default TypingIndicator;

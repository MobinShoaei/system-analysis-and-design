declare const _default: {
    defaultColor: string;
    backgroundTransparent: string;
    defaultBlue: string;
    leftBubbleBackground: string;
    black: string;
    white: string;
    carrot: string;
    emerald: string;
    peterRiver: string;
    wisteria: string;
    alizarin: string;
    turquoise: string;
    midnightBlue: string;
    optionTintColor: string;
    timeTextColor: string;
};
export default _default;

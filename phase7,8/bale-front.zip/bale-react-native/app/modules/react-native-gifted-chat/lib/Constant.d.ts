export declare const MIN_COMPOSER_HEIGHT: number | undefined;
export declare const MAX_COMPOSER_HEIGHT = 200;
export declare const DEFAULT_PLACEHOLDER = "Type a message...";
export declare const DATE_FORMAT = "ll";
export declare const TIME_FORMAT = "LT";

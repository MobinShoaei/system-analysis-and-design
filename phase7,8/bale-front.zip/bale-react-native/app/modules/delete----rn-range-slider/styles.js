import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  controlsContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  highThumbContainer: {
    position: 'absolute',
  },
  railsContainer: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  labelFixedContainer: {
    alignItems: 'flex-end',
  },
  labelFloatingContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'flex-end',
  },
  touchableArea: {
    ...StyleSheet.absoluteFillObject,
  },
});

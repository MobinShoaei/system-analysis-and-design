export default {
    app_en: 'bale',
    app_fa: 'پیام‌رسان بله',

    app_type: 'T'
}
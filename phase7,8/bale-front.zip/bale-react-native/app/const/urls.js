export default {
    backEnd: "http://185.235.40.19:5001",
    backEndAddress: "185.235.40.19:5001",
    
    otp:"/api/Member/otp",
    login:"/api/Member/login"
}
// modules
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
// import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { I18nManager } from 'react-native';
import 'react-native-gesture-handler';
// import * as Font from 'expo-font';
import { setCustomText, setCustomTextInput } from 'react-native-global-props';
import RNRestart from 'react-native-restart'; // Import package from node modules
import Toast from 'react-native-toast-message';
import { Provider } from "react-redux";
import { createStore } from "redux";
import colors from "./app/const/colors";
// lib
import { isSignedIn } from './app/lib/auth';
import { setupPushNotification } from './app/lib/PushNotification';
import allReducers from "./app/lib/redux/reducers";
// import {Restart} from 'fiction-expo-restart';
// import * as Updates from 'expo-updates'
import { MenuProvider } from './app/modules/react-native-popup-menu/src';
// screens
import Login from "./app/screens/auth/Login";
import ChatList from './app/screens/chats/ChatList';
import Single from './app/screens/chats/Single';
// import NoInternet from "./app/screens/common/NoInternet";
import SplashScreen from './app/screens/common/SplashScreen';
// import Exercises from './app/screens/mainApp/exercises';
// import MainApp from "./app/screens/mainApp/index";
// import Patients from "./app/screens/mainApp/patients";
// import Plans from "./app/screens/mainApp/plans";
// import Profiles from "./app/screens/mainApp/profile";
import { navigationRef } from './RootNavigation';


const Stack = createStackNavigator();
//  const navigationRef = createNavigationContainerRef()

if (I18nManager.isRTL != true) {
  I18nManager.forceRTL(true);
  I18nManager.allowRTL(true);
  setTimeout(() => RNRestart.Restart(), 300);

}
setupPushNotification();

export default function App() {

  const store = createStore(allReducers)

  const [loggedIn, setLoggedIn] = useState(false);
  // const [isActive, setIsActive] = useState(false)
  const [loading, setLoading] = useState(true)

   

  useEffect(() => {
    // onSignOut()
    isSignedIn().then(async signedIn => {
      if (signedIn) {
        setLoggedIn(true)
        // let active = await sendReq(urls.isUserActive, {}, 'get');//.then(active => {
        // setIsActive(active.data.active)
        // activateUser(active.data.active)
        // })

      }
    })

    // const loadFonts = async () => {
    //    
    // Font.loadAsync({
    //   'dana': require('./app/assets/fonts/dana/Dana-FaNum-Regular.ttf'),
    //   'danaThin': require('./app/assets/fonts/dana/Dana-FaNum-Thin.ttf'),
    //   'danaLight': require('./app/assets/fonts/dana/Dana-FaNum-Light.ttf'),
    //   'danaMedium': require('./app/assets/fonts/dana/Dana-FaNum-Medium.ttf'),
    //   'danaSemiBold': require('./app/assets/fonts/dana/Dana-FaNum-SemiBold.ttf'),
    //   'danaBold': require('./app/assets/fonts/dana/Dana-FaNum-Bold.ttf'),
    //   'danaBlack': require('./app/assets/fonts/dana/Dana-FaNum-Black.ttf'),
    // }).then(() => {

    setCustomText({
      style: {
        fontFamily: "dana",
      }
    })
    setCustomTextInput({
      style: {
        fontFamily: "dana",
        backgroundColor: colors.input,
        borderRadius: 10,
        textAlign: "right",
        padding: 4,
        paddingLeft: 15,
        color: colors.primary,
        // textAlignVertical: "top",
      }
    })
    // })
    // }
    // loadFonts()
    // checkSingIn()

    setTimeout(
      () => setLoading(false),
      1200
    )

  }, [])


  return (
    <Provider store={store}>

      <MenuProvider>
        <NavigationContainer ref={navigationRef}>
          <Stack.Navigator
            screenOptions={{
              headerShown: false
            }}>
             
            {loading &&
                <Stack.Screen
                name="SplashScreen"
                component={SplashScreen}
                />
              }
              <Stack.Screen
                  name="Login"
                  component={Login}
                />
              <Stack.Screen
                name="ChatList"
                component={ChatList}
                />
              
              <Stack.Screen
                  name="Single"
                  component={Single}
                />

            {/* <Stack.Screen
              name="NoInternet"
              component={NoInternet}
            /> */}
            {/* <Stack.Screen
              name="PatientStack"
              component={Patients}
            />
            <Stack.Screen
              name="PlanStack"
              component={Plans}
            />
            <Stack.Screen
              name="ExerciseStack"
              component={Exercises}
            />
            <Stack.Screen
              name="ProfileStack"
              component={Profiles}
            /> */}
          </Stack.Navigator>
        </NavigationContainer>
      </MenuProvider>
      <Toast ref={(ref) => Toast.setRef(ref)} />
    </Provider>
  );

}

